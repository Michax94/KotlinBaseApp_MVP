package pl.skipcode.basekotlinapp.feature.main.fragments.about

import pl.skipcode.basekotlinapp.feature.commons.BaseContract

interface AboutContract {

    interface View : BaseContract.View

    interface Presenter : BaseContract.Presenter

}